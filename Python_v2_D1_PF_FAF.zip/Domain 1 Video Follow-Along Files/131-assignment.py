x = 5
y = 3
print(x, y)
y = x
print(y)