x = 5
y = 3
result = x == 3 + 2 and y in [1, 2, 3] or x is not y
print(result)
# True and True or True