gases = ('Hydrogen','Helium','Nitrogen','Oxygen')
number_of_gases = 11
number_of_liquids = 2

print('Sodium' in gases and number_of_liquids < number_of_gases)

print('Hydrogen' in gases or 'Helium' in gases and number_of_liquids == 4)
