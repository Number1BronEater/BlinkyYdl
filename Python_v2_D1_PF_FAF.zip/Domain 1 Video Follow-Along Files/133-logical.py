unlock_level = True
target_score = 10000
score = 8000
if score < target_score or not unlock_level:
    print("You still have some goals to make")
else:
    print("Goals met")
