team1 = {"color":"red", "rank":1}
team2 = team1
team3 = {"color":"red", "rank":1}

print(team1 is team2)
print(team1 is team3)

