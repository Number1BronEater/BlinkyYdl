char_life = true
score = 0
if char_life == False:
    print ("game over")
else:
    print ("you are still in the game")    


