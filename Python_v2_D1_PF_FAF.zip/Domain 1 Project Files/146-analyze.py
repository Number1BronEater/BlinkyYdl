x = 500
y = 200
z = (1,2,3,5,8)
print (x % 6) #What will this result be? 2

x *= 3
print(x) # What will this result be? 1500

print(x > y and x in z) # What will this result be? False

print(x/5 > y or y not in z) #What will this result be? True