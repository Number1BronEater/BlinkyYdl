categories = ["Early Bronze Age", "Middle Bronze Age", "Late Bronze Age", "Bronze Age Collapse", "Early Iron Age"]
print(categories)

